
**Sore throat** : Dolor de Garganta.

**To have a sore** : Tener dolor de.

**To have a temperature** : Tener fiebre.

**Fever** : Fiebre.

**Headache** : Dolor de cabeza.

**Painkillers** : Analgésicos.

**I feel dizzy** : Estoy mareada/o.

**Suffer** : Sufrir.

**To pick up a bug** : Agarrar un virus.

**To get over** : Recuperarse.

**Got over a cold** : Superar un resfriado.

**Get plenty of rest** : Descansa mucho.

**Avoid dairy** : Evitar los lácteos.

**Make an appointment** : Concertar una cita. pedir cita.

**I had a check up** : Me hice un chequeo.

**A prescription** : Una receta (médica).

**Heartbeat** : Latido, Pulso.

**Sharp Pain** : Dolor agudo.

**Look out** : Cuidado

**Stand up** : Levantarse.

**Please be quiet** :  Por favor, silencio. 

**Quiet** : Tranquilo, silencio.

**Aubergine** : Berenjena.

**Argue** : Argumentar.

**Let's meet up over the weekend.** : Quedemos el fin de semana.

**Bench** : Banco.

**Cut back** : Recortar, Reducir.

**Eating more greens** : Comer más verduras.
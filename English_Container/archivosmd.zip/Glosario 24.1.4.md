**Taught** : Enseña, Enseño.
**Flew** : Voló (Volar en pasado).
**Pedestrian** : Peatones.
**The platform** : El andén. (En contexto de esperar el tren) O Plataforma.
**The gate** : Puerta o bien *En contexto de aeropuerto, **la puerta de embarque***.
**To depart** : Salir.
**To arrive** : Llegar.
**Reach** : Llegar a, acceder a.
**To be expected at** : Se espera que llegue.
**To be delayed** : Estar retrasado, Retrasarse.
**Overnight** : Durante la noche.
**Refund**: Reembolso.
**Am I able** ? : ¿ Soy capaz?.
**Arranging** : Organizando. Organizar.
**Poor weather conditions** : Malas condiciones climáticas.
**This may cause** : Esto puede causar // **May** : puede
**The underground** : El metro en contexto de transportes.
**Tube** : Tubo, Tubería.

---

![[Pasted image 20240104152517.png|200]]
Different ways to call the train services on european countries.

---

**A tram** : Un tranvía.
**Till** : Hasta
**Hire a car** : Alquilar un coche.
**Cuisine** : Cocina, Gastronomía.
**To go kayaking** : Ir en Kayak.
**Rather** : Más bien.
**Would Rather** : Preferiría.
**Snorkelling** : Buceo.
**Skiing** : Esquiar
**Barbacue** : Barbacoa.

## Maximum Challenge
**To be fond of** : Encariñarse con / Enamorarse de / Aficionarse a

*Maximus is fond of bad girls*

**To be crazy about** : Adorar.

*Maximus is behaving crazy in the toxic relationship*

**It's all the same to me** : Para mí es lo mismo.

*When Demien told him about the bad decisitions, He simply say "It's all the same to me, I don't mind"*

**I don't like it at all** : No me gusta nada.

*In the moment I knew about that relationship, I didn't like it all*

**Scratch** : Rasca, Arañar.

*It might have been that moment when Max started scratching Becky's hair, it was at this point when everything got weird*

**I can't bear it** : No puedo soportarlo

*I can't bear it, I told him not to do that*

**To be keen on** : A sido aficionado a

*I think he keen on her*

## Normal Path

**Had to give up** : Tuvo que renunciar.

**Indegenous** : Indígena.

![[Pasted image 20240118132424.png|500]]

![[Pasted image 20240118132808.png|500]]

**Lying in my bed** : Tumbado en mi cama, Acostado en mi cama.

*The lies it told me when we were lying in bed were the end of the last spark*

**Mainly** : Principalmente, Sobre todo.

**Plot** : Parcela. Trama.

**Disabled Person** : Persona discapacitada

**Suddenly** : De repente.

**Surprisingly** : Sorprendentemente.

**The door wide open** : La puerta abierta de par en par.

**Gradually** : Gradualmente 

**Immediately** : Inmediatamente.

**Strangely** : Extrañamente.

**OBVIOUSLY** : OBVIAMENTE.

**UNFORTUNATELY** : Desafortunadamente.

**is set in** : Se establece en, se ajusta en, se configura en.

**Play the role** : Interpretar el papel.

**Against all odds** : A pesar de todo.

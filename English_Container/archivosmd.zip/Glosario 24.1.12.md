**Are you moving there?** : ¿ Te mudas allí ?

**To look for a job** : Buscar trabajo.

**Job Hunting**, **Job Seeking**, **Job Searching** : Buscar Trabajo.

**Advert** : Anuncio, Publicidad, Aviso.

**To apply** : Presentar su candidatura.

**To send an application** : Enviar una candidatura, enviar una solicitud.

**Qualifications** : Cualificaciones, Titulación, Formación.

**Skills** : Competencias.

**I hope I made a good impression in my interview!** : Espero haber causado una buena impresión en la entrevista!

**Offered** : Ofrecido.

**Good fit** : Buen ajuste, buen encaje, buena adaptación.

### Job Questions
---
***What would you say are your strengths, and what are your weaknesses?***

---

**I look forward to hearing from you** : Espero sus noticias, Espero recibir noticias suyas.

**And drive for** : E impulso por.

**an so on** : Etc, Y así sucesivamente, y demás.

**Budget flight** : Vuelo económico.

**Small beach town** : Pequeña ciudad costera.

**Somewhere lively** : En algún lugar animado.

**Overall** : En general.

**Left much to be desired** : Dejaba mucho que desear.

**Was a bit rude** : Fue un poco grosero.

**Show someone around town** : Enseñar la ciudad a alguien.

---

![[Pasted image 20240112143706.png|400]]
![[Pasted image 20240112143751.png|400]]

---

**Removed without consent** : Retirado sin consentimiento.

**Urges** : Insta a, Urge.

***Advice** : Consejo.*

***Advise** : Aconsejar*

**Will cause ripples beyond** : Tendrá repercusiones (consecuencias) más allá de.

**Beyond** : Más allá de.

**The latter is due to reopen** : Este último debe reabrir.

**Is due** : Se debe.

**Amassed** : Acumulado.

**Rightfull owner** : Legítimo propietario.

**A hot spring** : Una fuente natural de agua caliente.

**A hot tub** : Baño caliente.

**To bathe/ to soak** : Darse un baño.

**The bathing macaques** : Los macacos que se bañan.

***Brought*** : Trajo.

**It's likely** : Es probable que.

**Passed down** : Transmitido, Heredado.


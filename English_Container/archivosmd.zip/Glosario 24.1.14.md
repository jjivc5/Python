
**To be overwhelmed** : Estar sobrepasado/a.

**To unwind** : Desconectar

**Deadlines** : Fechas de entrega.

**To have a lot on** : Tener mucho en, Estar repleto de cosas.

**To make time for** : Sacar tiempo para.

**Schedule** : Horario, Programa, Calendario. 

**To put pressure on oneself** : Ponerse Presión

**Me time** : Tiempo para mí.

**To take part in group therapy** : Hacer terapia de grupo.

**To join a walking club** : Apuntarse a un club de senderismo.

**Evening** : Por la noche, tarde.

**Struggling** : Luchando, con dificultades, con problemas.

**Workload** : Carga de trabajo.

**It's not up to us** : No depende de nosotros.

![[Pasted image 20240114150038.png|500]]


**Because of** : Debido a.

**Injury** : Lesión, herida, perjuicio.

**Relax best** : Se relaja mejor.
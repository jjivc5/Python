
**With over** : Con más de.

**Cricket** : Críquet.

**Fencing** : Esgrima.

**Boxing** : Boxeo.

**You are into something** : Significa que te gusta o te interesa el tenis.

**You are getting into tennis** : Significa que empiezas a interesarte en este deporte.

**Lifted** : Levantado.

**Trophy** : Trofeo.

**Mat** : Alfombrilla, estera, alfombra.

**Held** : Celebrar, Celebrado.

**Showpiece event** : Gran acontecimiento.

**Measure** : Medir, Mida, Medida.

**Thin** : Fino -- **Thinnest** : El más fino.

**What is your earliest memory?** : ¿ Cuál es su primer recuerdo?

**My most important possession.** : Mi posesión más importante.

**Peak** : Cumbre, Cima, Pico.

**Narrow** : Estrecho.

**I Overslept** : Me quede dormido.

**Mockingbird** : Sinsonte, Ruiseñor, Burlón.

**Though** : Aunque // **Though slower than** : Aunque más lento que.

**Land animals** : Animales Terrestres.

**To get in shape** : Ponerse en forma.

**To get a membership** : Para hacerse socio, para hacerse miembro, para ser miembro, Abonarse.

**In advance** : Por adelantado, con antelación, de antemano.

**Major challenge** : Reto importante.

**To lift weights** : Hacer pesas.

**My fitness goal** : Mi objetivo deportivo, Mi objetivo de entrenamiento.

**To work out** : Hacer ejercicio.

**Sore** : Dolor, dolorido, dolorida.

**To raise money for** : Recaudar fondos para una organización benefica.

**To sponsor** : Cuando apoyas a alguien haciendo donaciones para su causa.

**Homeless shelter** : Albergue para personas sin hogar.

**To as many as** : A tantos como.

**This cause is very close to my heart.** : Esto causa me toca muy de cerca.

**It really means the world to me.** : Significa mucho para mí.

**Be greatly appreciated!** : Se agradecerá mucho.

**I aim to** : Mi objetivo es.

**Therefore** : Por lo tanto.
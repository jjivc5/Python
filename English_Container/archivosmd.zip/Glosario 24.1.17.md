**Brought** : Traído, trajo, llevado **Bought** : Comprado, Comprado en, Compré.

**I gave a lift to the party** : Llevé a la fiesta, Le di un aventón a la fiesta.

**Student loan** : Préstamo estudiantil.

**A wristband** : Una pulsera

**Pitch your tent** : Monta tu tienda, montar la tienda. **Tent** : Tienda de campaña.

**A blend** : Una mezcla, una combinación.

**Glamping** : Es una combinación de Glamour y Camping, no tiene traducción.

**Headliners** : Cabeza de cartel.

**You name it** : Lo que se te ocurra, Lo que quieras.

**Wellies, gum boots, rain boots** : Botas de agua.

**Delighted** : Encantado.

**Unlikely** : Improbable.

**To be packed with** : Para estar repleto de

**Utterly** : Totalmente.

**Your way arround** : Tu camino. Tu camino por los alrededores.

**If you attend** : Si asiste a.

**Frightfully** : Espantosamente.

**Accomodation** : Alojamiento.
**The present** : El regalo.
**Kidney** : Riñon.
**Lift** : Ascensor. // *I need a lift till there* = Necesito que me lleven hasta allí.
**Mud Wrestiling** : Lucha contra el barro.
**Mud** : Barro.
**Won't** : Forma negativa de will, ***no lo haré : I Won't***
**Fianceé** : Prometido, prometida, novia.
**Gosh** : Dios
**Abroad** : En el extranjero.
**Leisure** : Ocio. Tiempo Libre.
**Trip** : Viaje.
**Cruise** : Crucero.
**Staycation** : Estancia, Vacaciones en Casa.
**Involved** : Implican.
**A package holiday** : Un viaje Organizado.
**To book a flight** : Reservar un vuelo.
**Accommodation** : Alojamiento.
**Transfer** : Translado.
**Visa** : Visado.
**Itinerary** : Un itinerario
**Per** : Por
**Waterfall** : Cascada.
**Saw** : Ver en pasado / *I Saw It* = Lo Vi.
**Bright** : Brillante.

--- 

### Corrección
> I'd would like to go visit the Iguazu's waterfall because they're on the north of my country, and i never went there.

>I'd (**Ya contiene el would**) like to (**Sin el go**) visit the Iguazu's waterfall because they're **in**, and I have never been there.

---

**A hostel** : Un albergue.

**B&B** : Un hostal = A bed and Breakfast.

**A campist** : Un camping.

**Tents** : Tiendas. Carpas.

**Campers** : Autocaravanas.

**Straight** : Recto // ***Go straight to** : Ir directamente a*

**Check in** : Registrarse.

**To Check out** : Salir.

**Noon** : Mediodía.

**Van** : Furgoneta.

**To sunbathe** : Tomar el sol.

**My Tan** : Mi bronceado.

**Faded** : Descolorido, desteñido. (Desvancerse)

**Souvenir** : Recuerdo, Recordatorio.

**Magnet** : Imán.

**Postcart** : Carta Postal.


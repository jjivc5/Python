## Parte 1
**We won't been using the meeting room *then*** : *Entonces* no usaremos la sala de reuniones.

**I won't be sleeping then.** : Entonces no dormiré

## Parte 2

**Foreigners** : Extranjeros.

**Neighbourhoods** : Vecindarios, Barrios.

**Green spaces** : Espacios verdes.

**Ancient Ruins** : Ruinas.

**Residential Areas** : Zonas residenciales.

**Parthenon** : Partenón.

**Well-preserved buildings** : Edificios bien conservados.

**But its** : Pero su, sino su, pero sus.

**Is just as exciting** : Es igual de emocionante.


## Parte 3

**A busy city** : Una ciudad ajetreada.

**The sights** : Las vistas, los lugares de interés.

**Skyscrapers** : Rascacielos.

## Parte 4

**Architect** : Arquitecto.

## Parte 5

**Each grammar tense has its own passive form.** : Cada tiempo gramatical tiene su propia forma pasiva.

**Grammar tense** : Tiempo gramatical.

![[Pasted image 20240121155333.png]]


## Parte 6

**Must be made** : Debe hacerse.

**Affordable** : Asequible.

**Nursing Homes** : Residencias de ancianos.

**Could be cared for close to home.** : Podría ser atendido cerca de casa.

**Housing** : Vivienda.

# Parte 7

**Written** : Escrito. *(Participio pasado de ""to write")*

**Envelope** : Sobre

**Heard** : Escuchado. *(Participio pasado de "To hear" : oír)*

**Hurt** : Herido. *(Participio pasado de "To hurt" : Herir)*

**Suitcases** : Maletas.

**Brought** : Trajo, Trajeron.  *(Participio pasado de "To Bring")*

**Bought**: Compró *(Participio pasado de "To buy")*

**Tought** : Pensó, pensado *(Participio pasado de "To think")*

**Taught** : Enseñó *(Participio pasado de "To teach")*

## Parte 8

**Ocean liners** : Trasatlánticos.

**Litographic printing** : Impresión litográfica.

## Parte 9

**Motorway** : Autopista.

## Parte 10

**Was founded** : Se fundó.

**Huge outdoor playground** : Enorme parque infantil al aire libre.

**Scarce** : Escasos.
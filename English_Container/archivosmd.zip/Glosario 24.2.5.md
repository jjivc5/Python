**A potty mouth** : Un boca sucia

**Swear word** : Palabrota

**What the hell?** : ¿Qué demonios?

**What the heck?** : ¿Qué narices?

**Fucking** : Jodido/a, maldita.

**The coffee is bloody disgusting** : El café es un maldito asco.

**Freaking** : Es un fucking más light.

**The coffee is freaking hot** : El café está terriblemente caliente!

|**strong** 🔥🔥🔥|**mild** 🔥🔥|**soft** 🔥|
|---|---|---|
||hell|heck|
|fucking|bloody|freaking|
|shit|crap|shoot|
||damn|darn|
**Crap** : caca, una mierda.


**Shoot! I forgot to send invites to the meeting.** : ¡Mierda! Olvidé enviar invitaciones a la reunión.

**Damn** : "Damn" es una palabrota que significa que mandamos a alguien al infierno y hace referencia a la religión.

**Darn** : Damn con menos cafeína.

**Darn, it's cold in here** : ¡ Caray, que frío hace aquí !

---

- upward trends – when something is going up 📈
- downward trends – when something is going down 📉
- stability – when there's no change

**To grow** : Crecer.

**To increase** : Aumentar.

**Rose significantly** : Aumento significativamente, rose es pasado de "rise" y no es rosa en este caso.

![[Recording 20240205123115.webm]]

**To decline** : Reducirse.

**To drop** : Bajar.

**To remain stable** : Mantenerse estable.

**To hold steady** : Mantenerse constantes.

---

| Trends  | Sentences  |
|---|---|
|Upward trends|to increase  <br>to grow  <br>to rise  <br>to be on the increase  <br>to be on the rise|
|Downward trends|to decrease  <br>to drop  <br>to decline  <br>on the decrease  <br>on the decline|
|Stability|remain constant  <br>stay unchanged  <br>hold steady|

---

**The figures show (that)** : Las cifras demuestran que.

**On average** : De media.

**To be likely to** : Es probable que.

**According to the statistics...** : Según las estadísticas.

**Statistically speaking...** : En términos estadísticos.

**To account for** : Representar.


If you find yourself discussing numbers in an informal setting, you can say "**stats**" instead of "statistics". En términos más informales se puede decir "stats"

+ We've just received the performance **stats** for this quarter.

**To see a rise in...** : Registrar un aumento de

**Circulatory disease** : Enfermedad circulatoria.

**Bright spot** : Punto brillante.

**With a gulf in outcomes** : Con un abismo en los resultados

**Rather** : Más bien, En lugar, En lugar de.

---

When we want to say how much something has changed statistically, we use the preposition "**by**".

Food prices have gone up **by a third** this year.


**An active holidays** : Unas vacaciones activas.

**Lie on the** : Tumbarse, se encuentra en el. (No es solo mentir Lie.).

**City Break** : Escapada urbana.

**Beach getaway** : Una escapada a la playa.

**A luxury stay** : Una estancia de lujo.

**Luxurious** : Lujoso.

**Boutique** : Tienda.

**Vineyards** : Viñedos

**Forecast** : Previsión, Pronóstico.

**Scuba diving** : Buceo.

**Scuba diving trip** : Viaje de submarinismo.

**They are moving house soon.** : Se están por mudar pronto.

**Surprisingly** : Sorprendentemente.

**Disappointing** : Decepcionante, desilusionante.

**Look very inviting** : Parecen muy atractivas.

**Helpful** : Útil. **Were so helpful** : Fueron tan serviciales.

**Unforgettable** : Inolvidable.

**The highlight** : Lo más destacado.

**Jaw-dropping** : Alucinante

**To do something justice**

**Desired** : Deseado

**Toured** : Visitó, Recorrió.

**Marshmallow** : Malvavisco.

**Pillow** : Almohada.

**Smelled funny** : Olía raro.

**Hammocks** : Hamacas.

**Backpackers** : Mochilero

**All in all** : En general, en resumen, en conjunto.

**All that said** : Dicho esto, Lo dicho.

**Was rather dissapointing** : Fue bastante decepcionante.

**Goes hand in hand** : Va de mano en mano, significa estar relacionado con algo.
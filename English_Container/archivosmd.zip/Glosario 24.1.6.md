**Can you make it to my party?** : Acá el Can You Make It, equivalente al puedes hacerlo pasa a tomar sentido en el **contexto** a ***puedes venir a mi fiesta?***.

**Sure, Count Me In!** : Seguro , conta conmigo!.

**RSVP** : Se ruega confirmar la asistencia.

**Housewarming** : Inauguración de la casa.

**Bring** : Traer, Traiga.

**Afraid** : Miedo, Asustado, Teme.

**That's a shame!** : ¡ Qué pena !.

**Plenty** : En abundancia, mucho, abundante. **Plenty of** : Un montón de.

**Anymore** : Más, ya, ya no.

**Any more** : Algo más de

**There's no room.** : Puede ser No hay sitio, No hay espacio, No hay lugar, No queda sitio.

**To throw a party** : Dar una fiesta. (**Thrown is the past of throw**)

**Bachelor party** : Despedida de soltero.

---

Despedida de soltero, dependiendo el sexo y si es UK or US

![[Pasted image 20240106143835.png|600]]

---

**A venue** : Un Local.

**Dining room** : El comedor.

**Help yourself** : Sírvete. (**Dig in *Una manera informal de decir que te sirvas la comida.***)

**Do you want seconds?** : ¿ Quieres repetir ?.

**Leave room for dessert.** : Deja espacio para el postre.

**Would you like a top-up?** : ¿ Queres más ? o ¿ Queres una recarga?.

**It's not as busy there as** :  No está tan concurrido como.

**Bow slightly** : Inclinarse ligeramente. **To bow** : hacer una reverencia.

**Greet** : Saludar, Saluda a.

**Host** : Anfitrión.

**Flavour** : Sabor.

**Blueberry** : Arándanos.

**What did Ramon's friend make?** : ¿Qué hizo el amigo de pepe?

**What were Sasha and her friends talking about?** : ¿De qué hablaban Sasha y sus amigas?

**Attended** : Asistió a, Visite.
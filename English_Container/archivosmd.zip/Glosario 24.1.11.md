**Sign** : Firmar, Firme.

**To get a phone contract** : Obtener un contrato telefónico. // Busuu : Conseguir un número de teléfono.

**To look up** : Buscar.

**Embassy** : Embajada.

**A plan** : On cellphones context it's "Tarifa"

**Per month** : Al mes.

**I got a great deal** : Conseguí un gran trato, Conseguí un buen trato, Tengo un gran trato, Conseguí una gran oferta.

**I got a great deal on my new cellphone.** : Conseguí mi móvil nuevo a buen precio.

**To bear** : Soportar.  **To bear with someone** : Esperar.

**To go for something** : Elegir.

**To take down something** : Anotar.

**No worries** : No te preocupes.

**By the way** : Por cierto.

**You're good to go** : Ya está todo.

**Your account is all set up** : Tu cuenta ya esta lista.

**If that's ok** : Si estas de acuerdo.

**Bear with me a sec** : Espera un momento por favor.

**Is spoken widely** : Se habla mucho.

**Widely** : Ampliamente.

**Which statement summarises** : Que afirmación resume?

**Occasion** : Ocasión.

==**A venue** : Un Local. (Repetida 3 oraciones obligatorias, para marcar)==

**Well in advance** : Con mucha antelación.

**Dress code** : Código de vestimenta.

**Bring a plus one** : Traer un acompañante.

**A Seating Plan** : Plano de Asientos.

**To propose a toast** : Proponer un brindis. **Toast** : Tostada, Brindis.

**What's the occasion?** : ¿Cuál es la ocasión? o ¿Qué se celebra?

**Joint** : Conjunta, Conjunto. Articulación.

**Gazebo** : Cenador, Mirador, Glorieta.

**To catch up** : Para ponerse al día.

**Boardgames night** : Noche de juegos de mesa.

**To have over people** : Tener visita.

**A get-together** : Un encuentro.

**BYOB** : Lleven su propio escabio a la fiesta. Bi Guai Ou Bi == Bring Your Own Booze : Tráete tu propio alcohol.

**Unfortunately** : Por desgracia, lamentablemente.

### WTF Moment

**I am a great cook, aren't I?** : Osea es simple, Soy un gran cocinero, a que sí(verdad,no)?. Se usa el aren't porque pueden, pero es correcto gramaticalmente y se usa en el tipo de preguntas tag.

---

**It's been ages** : Han pasado años.

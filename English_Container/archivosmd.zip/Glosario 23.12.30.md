>**Cutlery**: Cuchilleria.
>**Pots**: Ollas.
>**Ironing**: Planchar, planchado.
>**Duster**: plumero, trapo, paño, sacudidor
>**Hallway**: pasillo, vestibulo.
>**Chope**: cortar.
>**Slice**: rebanar.
>**Pepper**: pimiento
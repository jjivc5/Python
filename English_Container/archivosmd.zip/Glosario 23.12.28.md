>**Nearly** : cercano, proximo
>**Split**: separar, partir, dividir, romper
>**Split up**: separarse.
>**Upset**: alterado, decepcionado.
>**Really upset**: Realmente molesto.
>**Before** : Antes
>**After**: Después
>**Engaged**: comprometerse, ocupado llamado.
>**Statutory** : estutario. Reglamentario, obligatorio
>**Taster**: Catador
  **Boarding school** : Internado.
>**Aware** : consciente
>**Throb** : palpitante
>**Revise** : revisar
>**Dessert** : postre
## Palabras de pronunciar en conjunto horribles (Words awful to pronuntiate togethers)
+ Ice, Eyes
+ Weren't went
+ Rice, Rise

# Paragraph
- When i was *nearly* to the bank i *split up* from my partner. He get *really upset* after *engaged* to *revise* all the books. These books was storaged in the *boarding school* and the statutory doesn't allow to eat the *dessert* in the library and my partner loves to do that. *Before* he goes i had a *throb* about this and i was *aware* that my job of *taster* cakes would be better for him. *After* i ended, i was happy anyway
## Chat Gpt Correction:
"When I was nearly at the bank **,** I split up from my partner. He **was** really upset after **getting** engaged to revise all the books. These books **were stored** in the boarding school **,** and the statutory rules **didn't** allow **eating** dessert in the library, **something** my partner **really loves to do**. Before **he left** **,** I had a throb about this **,** and I was aware that my job **as a taster of cakes** would be better for him. After i ended, i was happy anyway"
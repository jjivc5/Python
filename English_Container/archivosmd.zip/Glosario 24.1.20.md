**Knit** : Punto, Tejer

*I knitted a small bag*

**If you aren't sure which one to use, "used to" will always work.**

![[Pasted image 20240120124356.png|500]]
## Parte 2
**Blended** : Mezclado.

**Surrounded** : Rodeado.

**A single-parent household** : Un hogar monoparental.

**Household** : Hogar.

**Twins** : Gemelos/as.

**Special Bond** : Vínculo especial // **Bond** : Bono, Enlace, Vínculo, Fianza.

**Soap operas** : Telenovelas.

## Parte 3

**To ask somebody out** : Invitar a alguien a salir.

**To fall in love with** : Enamorarse de.

**To get engaged to** : Comprometerse con.

## Parte 4

**Flatmates** : Compañeros de piso.

**Had hung out** : Había pasado el rato.

**Jealous** : Celoso, Envidioso.

**Crowded** : Abarrotado, Atestado.
**My Local** = It's use to describe a place that's in area near to you. Also in the UK you can use it for refeer to a place you visit frequently
**Held** : Celebrada
**Venue** : Lugar de Celebración, Lugar de reunión.
**Worship** : Adoración, cultos.
**A mosque** = An Islamic place of worship. : Una mesquita.
**A synagogue** = A Jewish place of worship : Una sinagoga.
**A temple** = A place for many types of worship, like Hinduism or Buddhism.
**Square** : Plaza (En términos de lugares)
**Gather** : Recoja, Recoger. // *People can gather : La gente puede reunirse*
**fair** : Feria
**Around the corner** : A la vuelta de la esquina.
**Ferris Wheel** : Noria, Rueda de la fortuna.
**Mall** : Centro Comercial.
**The Bakery** : La panadería.
**Down the street** : Al final de la calle.
**Whilst** : Mientras que. *She passes a post office **whilst travelling to work*** = Ella pasa por delante del correo cuando va a su trabajo.
**To stay in** : Para quedarse en.

---
![[Pasted image 20240103143239.png|500]]

---
**Through** : A través de.
**Go past** : Pasar.
**Beside** : Junto al.
**Along** : A lo largo // *Along the road == **A lo largo de la carretera**.*
**Deli** : Charcutería o delicatessen -> Es una tienda que vende alimentos especiales.
**To come across** : Encontrar.
**Across** : A través de.
**Few** : Algunos, Pocos, Unos.
**By chance** : Por casualidad.
**Nearby** : Cerca de
**Useful** : Útil.
**Welsh** : Gales.
**Local delicacy** : Exquisitez Local // **Delicacy** : Delicadeza.
**Laverbread** : Pan de lava.
**Seaweed** : Algas.
**Looking forward** : Mirando al futuro. // **Looking forward to** : Esperando.
**Local newsagent's** : Quiosco Local.
**Sat** : Sentarse.

---

**There is** : Se utiliza para referirse a cosas incontables. *There is some milk **Hay algo de leche***.
**There are** : Se utiliza para referirse a cosas contables. *There are some bananas **Hay algunas bananas***

---

**Cropping** : Recortando. **Crop** : Recortar.
**Hover** : Pasar el ratón por. // *Hover effect, esto se refiere a un efecto al pasar el ratón por encima del elemento*.

**Sticky** : Pegajoso.

**It avoid** : Evita.

**Having to type messages** :Tener que escribir mensajes.

**Anyway** : De todos modos.

**Handpainted** : Pintado a mano.

**Exciting** : Emocionante.

**The game has frozen** : El juego se ha colgado.

**Score** : Puntuación.

**A raid** : Un ataque por sorpresa / **To raid** : Atacar por sorpresa.

**Raiding** : Asalto, Incursión.

**Afterwards** : Después, a continuación, posteriormente.

**Though** : Aunque **Thought** : Pensó, Pensamiento. **Through** : A través de.

**There were loads** : Había montones, había un montón.

**Amid** : Entre.

**Strobe lights** : Luces estroboscópicas.

**Booming** : En auge.

>**To stage** : ==Organizar.== 

>**To lure** : ==Atraer.==

**To nurture** : Cuidar

**Avid** : ávido. == *Ansioso, codicioso.*

**Maladjusted** : Inadeacuado.

**Facility** : Instalación (Lugar físico).

**It will hold up** : Aguantará. **it will hold up to thousand peoples** : Puede albergar hasta mil personas // *También la podemos usar para referirnos a albergar gente*.

**Gather** : Reunir, recoja. **Will Gather** : Reunirá.

**Each other compete** : Competir entre sí.

**Revenue** : Ingresos, facturación.

**Increasingly firms are staging** : Cada vez más empresas.

> **Increasingly** : ==Cada vez más.== 

**Firms** : Empresas **Staging** : Puesta en escena, escenificación.

**Hole up for hours** : Esconderse durante horas.

**Play for hours in the dark, alone but for their consoles.** : *Se combina but con for. Quedando but for y el significado es* : Juegan durante horas en la oscuridad, con la única compañía de sus consolas. (Lo cual el traductor gpt no interpreta así).
***But for** puede utilizarse también como **except for**.*
****

**As competitive gaming is known** : Como se conoce al juego competitivo.

**To nurture an avid fanbase** : Cultivar una base de fans ávidos.

**In other ways, too** : También en otros aspectos. También de otras maneras, formas, sentidos.

**Plus** : Más. Además.

## Formulación de Oraciones.

*To stage a main event* : Para organizar un evento principal.

*I want to lure a lot of money* : Quiero atraer un montón de dinero.

---

*I am increasingly learning more English words* :  Cada vez aprendo más palabras en inglés.

*If i see you, I increasingly want to stay with you* : Si te veo, cada vez más quiero estar contigo.
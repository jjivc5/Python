## Cocina
**Kettle**: pava,tetera, hervidor.
**Grill**: poner en la parilla, asar.
**Roast**: asar, por largo tiempo.
**Oven**: horno.
**Stir**: Agitar, revolver.
**Smooth**: alisado, fluido.
**Courgette**: Calabacín
**Flakes**: copos, hojas. Etc
**Bake**: Hornear
**Garlic**: ajo. // Garlic Cloves: Dients de ajo.
**Cloves**: Clavos de Olor...
**Crush**: Aplastar.
**Simmer**: Hervir a fuego lento.
**Mince**: Desmenuzar, Picar (US)
**Pour**: Verter.
**Stew**: Guiso
**Toffee**: Caramelo
**Oat Milk**: Leche de Avena
**Soy Milk**: Leche de Soja
**Almond Milk**: Leche de Alemendras
**Whisk**: Batidor, Batir
**Grate**: Rallar
**Spoil**: Estropear, Arruinar
**Booked**: Completado, Reservado.
**Napkins**: Servilletas
**Keen on**. Con ganas de, Deseoso de, Muy interesado en.
**Keen**: En, Muy atento.
**For Starters**: Para empezar
**Main Course**: Plato Principal
**Medium Rare**: Medio Crudo.
**Dish**: Plato
**Spicy**: Picante
**Cod**: Bacalao
**A side of chips**: Una guarnición de papas fritas.
**Side dishes**: Guarniciones.
**Can of**: Lata de
**Dairy-free**: Libre de Lacteos
**Avocado**: Aguacate
**Ginger**: Jengibre
**Sore Throat**: Dolor de Gargante
**Sour**: Agrio
**Bitter**: Ama
**Cured Jam**: Jamón crudo
**Crisps**: Papas Fritas.
**Steak** : Filete
**Savoury**: Salado (Umami también) It's like slightly salty
**Salty**: Salado más que Savoury
**Tasty, Yummy, Delish**: Delicioso.
**Molten**: Fundido (Like Molten CheeseCake)
**Bland**: Soso, insipido.
**Greasy**: Grasiento.
**Lizard**: Lagarto
## Ropas
**Jumper** : Jersey, Sueter, Buzo? = Sweater en US
**Trainers**: Zapatillas = Sneakers en US
**Trousers** = Pants US : Pantalones
**Pants**= Panties US : Bragas, Calzones
**Heels**: High-heleed shoes. Zapatos de tacón alto.
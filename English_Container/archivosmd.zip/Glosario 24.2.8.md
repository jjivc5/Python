
**To sprain your wrist** : Torcerse la muñeca.

**To bruise your arm** : Hacerse un moratón en el brazo.

**Lifting** : Elevación, elevador, elevar.

**To trap your fingers** : Pillarse los dedos.

**To pull a muscle** : Dar un tirón. Sufrir un tirón.

**I nearly pulled a muscle** : Casi me da un tirón.

**To break a bone** : Romperse un hueso.

**Hip pain** : Dolor de cadera.

**I broke a bone while handling a heavy box.** : Me rompí un hueso mientras movía una caja pesada.

---

**Workplace hazards** : Riesgos laborales. Peligros en el lugar de trabajo.

**Aims to** : Tiene por objeto, pretende.

**To start with** : Para empezar.

**Let me move on to** : A continuación, abordaré.

**That brings me to the point** : Eso me lleva al hecho.

**Let me finish by saying** : Terminaré diciendo.


|**FUNCTION**|**EXPRESSION**|
|---|---|
|introducing purpose|this presentation aims to|
|introducing points|to start with|
|linking information|that brings me to the point|
|concluding the presentation|let me finish by saying|

---

**Janet would prefer to stay in to do her workout.** : Janet prefiere quedarse en casa para hacer ejercicio.

**To lift weights** : Levantar pesas.

**To extend your leg** : Extender la pierna.

**To flex your toes** : Flexionar los dedos de los pies.

**Strengthen** : Reforzar, fortalecer, fortalezca.

|   |   |
|---|---|
|✅|❌|
|He was trying to flex **his** toes.|He was trying to flex ~~the~~ toes.|
|I extended **my** leg.|I extended ~~the~~ leg.|


**Keep your core tight throughout the whole exercise.** : Mantenga el tronco contraído durante todo el ejercicio.

**Goes all the way up.** : Sube hasta arriba.

|  Body part  |  Meaning |
|---|---|
|abs|abdominal/stomach muscles|
|glutes|gluteal/buttocks muscles|

**Heels** : Talones, *Don't hurt your heels*

**To bend** : Doblar, Flexionar, Inclinarse.

**To squeeze your butt** : Contraer los glúteos.

**To keep your core tight** : Mantener tu centro firme

**Mat** : Alfombra.

---
**Body image** : Imagen corporal.

**Love the skin you're in** : Ama tu cuerpo.

**Body shaming** : Humillación física.

- **A misconception (n)**: an idea that is based on something that is not correct
- **To raise awareness (v)**: to make people know that a situation exists and is important

**Overweight** : Sobrepeso.
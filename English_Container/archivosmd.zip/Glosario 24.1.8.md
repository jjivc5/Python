
**We wish you the best** : Te deseamos lo mejor.

**They hope for the best** : Esperan lo mejor

**She hopes so** : Ella lo espera.

**So fingers crossed we win.** : Así que crucemos los dedos para que ganemos.

**Raincoat** : Impermeable.

**She'd rather** : Ella preferiría.

**Accountant:**  Contador.

**Time off work** : Vacaciones.

**I'll know what clothes to pack.** : Sabre que ropa meter en la maleta.

**Chopsticks** : Palillos (Para comer).

**Cease** : Cesar, terminar, dejar.

**Short getaway** : Escapada corta.


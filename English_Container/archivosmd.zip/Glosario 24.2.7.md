
**She looks very approachable** : Parece muy accesible.

**She looks like my sister-in-law** : Se parece a mi cuñada.

**She looks like she likes spending time with people** : Parece que le gusta pasar tiempo con la gente.

When we describe something using verbs such as "**to look**", "**to smell**", "**to taste**" or "**to feel**", we can use them in three ways. 

|   |   |
|---|---|
|1️⃣ She looks friendly.|**looks** + adjective|
|2️⃣ It looks like cheese.|**looks like** + a noun|
|3️⃣ It looks like you've cooked it too long.|**looks like** + a verb phrase|

**Swiped right** : deslizó a la derecha, deslizado a la derecha.

**Swiped** : Birlado, buceado, birló. Robar.

**June's hair smells like lavender** : El pelo de June huele a lavanda.

**My ice cream tastes like heaven** : Mi helado sabe a gloria.

**June's hands feel soft** : Las manos de June son suaves.

**It feels like we've known each other forever**  : Parece que nos conocemos desde siempre.

*It feels **as if** we've known each other forever.* Another way to say the same.

**Its fur feels super smooth** : Tiene el pelo supersuave.

**Bitter** : Amargo.

  

Try using the language we've looked at in this lesson.

| Cheatsheet  | |
|---|---|
|It looks/smells/feels/ tastes **great (adjective).**| |
|It looks/smells/feels/tastes like **cheese (noun).**| |
|It looks/smells/feels/tastes like/as if **you've just bought it (verb phrase).**| |

---

**Wrist** : Muñeca.

**Wrinkles** : Arrugas.

**Calf** : Pantorrilla.

**Wrap** : Envolver todos estos regalos.

**My calves** : Mis gemelos.

**Unbereable** : Insoportable.

---

**To lose your balance** : Perder el equilibrio.

**The anchor would certainly stop me** : El dispositivo de seguridad sin duda me detendría.

**To lean back** : Apoyarse.

**Belt** : Cinturón

**To hold something tightly** : Sujetar algo con fuerza.

**To cramp** : Tener calambres

**Wear and tear** : Desgaste.

**A knee replacement** : Una prótesis de rodilla.
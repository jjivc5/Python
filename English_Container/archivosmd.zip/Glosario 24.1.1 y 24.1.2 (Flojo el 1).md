**Lenses** : Lentes
**The fitting room** : El Probador.
**Those clothes doesn't suit in her** : Esta ropa no le quedan bien.
**Loose** : Flojos, Sueltos, Holgados (ropa).
**Fit** : Ajuste, Encajar.
**Tight** : Apretado.
**Smart** : Inteligente, Pero a la vez... aplicado a ropa o look **Smart Look** : Aspecto Elegante.
**Fashionable** : A la moda
**Ripped** : Desgarrado, Rasgado  -> **Ripped Jeans : Jeans Rotos**
**On trend** : En tendencia, a la moda.
**Trendy**: De Moda.
**Crop Top** : Top corto.
**CatWalk** : Pasarela.
**Wore** : Llevaba.
**Worn** : Desgastado.
**Neither** : Ni, tampoco. Ni En.  = **Nor** But it's come then like Neither cheap nor expensive == Ni barato ni caro.
**On Sale** : A discount for a product
**BOGOF** : Buy One. get one free.
**The till** : La caja registradora, la caja.
**Either** : O bien, ya sea, o.
**Chore** : Tarea.

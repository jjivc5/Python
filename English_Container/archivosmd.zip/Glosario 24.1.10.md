**Lively** : Animado.

**Cosmopolitan** : Implies influence for different countries and cultures. No tiene definición directa al español.

**Long-established custom** : Costumbre establecida.

**Picturesque** : Pintoresco.

**Faced** : Enfrentado, se enfrentó a, encarado.

**Her window faced** : Su ventana daba a ...

**Noisy** : Ruidoso/a.

**Polluted** : Contaminado, Contaminada.

**Noisier** : Más ruidoso.

### Regla
**Fewer** -> Contable ... Less -> Incontable.

---

**Old-fashioned** : A la antigua, anticuado.

**Less touristy city** : Ciudad menos turística.

**A coral reef** : Un arrecife de coral.

**In clear, warm waters.** : En aguas cristalinas y cálidas.

**A sandy beach** : Playa de arena.

**Couples** : Parejas.

**Sunset** : Puesta de sol.

**Cliff** : Un acantilado.

**Grassy Cliff** : Un acantilado cubierto de hierba.

**Damp** : Húmedo.

**Climbers** : Montañista (Escalador, Trepadores).

**Stood at**   : Se paró en, Situado en, Se quedó en.

**Seashells** : Conchas Marinas.

**Caught** : Atrapo. Capturo

**Happily** : Felizmente.

**Wave** : Ola. (Una ola del Mar)

**Sunrise** : Amanecer.

**A coast** : Una costa.

**To fill out forms** : Rellenar formularios.

**Tenant** : Inquilino.

**Landlord** : Propietario.


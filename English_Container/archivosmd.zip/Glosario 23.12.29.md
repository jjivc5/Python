>**Waiter**: Mesero, El Mozo.
>**Due**: Debido, Oportuno, Esperado, Apto. I had to leave my job due to health reasons. Otro ejemplo The Report is Due Friday (El reporte vence el viernes o se debe para el viernes).
>**Slight**: Ligero/a, Pequeño, Escaso.
>**Interchangebly**: Indistintamente.
>**Departing**: Partiendo, Dejando.
>**That this**: Que esto.
>**In the fall**: En el otoño. Fall por si solo es caída también.
>**Meeting first thing**: Reunión a primera hora.
>**To book time off**: Periodo de ausencia en el trabajo.
>**Period of absence**: periodo de ausencia.
>**Off sick**: de baja por enfermedad // off sick with the flu = Enfermo con la gripe.
>**Draft**: Borrador, documento, plan preliminar.
>**Shall**: Deber, tener que // Shall we move on - Seguimos adelante?.
>**To sum up**: Para resumir, en resumen.
>**Any further thing**: Alguna cosa diferente (Alguna " " adicional), funciona con otras palabras también.
>**Action items**: elementos de acción tareas a realizar.
>**Might**: Podría, poder.
>**Sink**:Fregadero, lavadero, hundirse.
>**The washing up**: el lavado.
>**Vacuum**: vacio, aspirar.
>**Sweep**: barrer (en términos de limpieza).
>**Mop**: fregar.
>**Broom**: escoba.
>**Wet soapy mop**: trapeador humedo y jabonoso.
>**Rubbish**: basura.
>**House chores**: tareas de la casa.
>**Groceries**: comestibles.
>**Tidied**: ordenada/o.
>**Boilerplate**: repetitivo en contexto HTML.
>**Fetch**: buscar.
>**Wrap**: envolver.

**Cheerful** : Alegre.

**Sunflowers** : Girasoles.

**Easy-going** : De trato fácil.

**Charming** : Encantador / Encantadora.

**Orchid** : Orquídea

*The master orc of the sharp orchid* : ***El orco maestro de la orquídea afilada*

**Confident Person** : Persona segura de sí misma.

**Bouquet** : Ramo, Ramo de flores.

**Caring** : Cariñosa, Cariñoso.

**Peones** : Las peonías.

**Thoughtful** : Considerada/o.

**Pleasant** : Agradable.

**Humble** : Humilde.

**About her marks** : Sobre sus marcas, notas, huellas.

**Shy** : Tímido/Tímida.

**Pass her finals** : Aprobar sus finales, los finales.

**Hard-working** : Muy trabajador.

**Clever** : Inteligente.

**Silly** : Tonto. **Sloppy** : Descuidado.

**My earliest childhood memory** : Mi primer recuerdo de la infancia.

**A clear memory** : Un recuerdo claro.

**To remind of** : Recordar.

**Even though** : Aunque, a pesar de que, a pesar de.

### Parte 4

**To get to the bottom of** : Llegar al fondo de.

**Get rid of** : Deshacerse de.

**To get on with** : Llevarse bien con.

**To get away with** : Salirse con la suya, librarse de las consecuencia

### Parte 5

**Senses** : Sentidos.

**Gingerbreads cookies** : Galletas de Jengibre.

> *Do you want to taste this? and how do it is taste?*
> En esta oración usamos los dos sentidos de taste.
> **Queres probar esto? y A que sabe?**

**Cinnamon Cookies** : Galletas de canela.

**Weighing** : Pesaje, Pesando.

**Confectionary shop** : Confitería.

### Parte 6

**To keep in touch** : Mantenerse en contacto. **Kept is the past form of keep**

**To be on the same page** : Estar en sintonía.

**Ran smoothly** : Funciono sin problemas.

**To get along with** : Llevarse bien con.

**Aside from a few.** : Aparte de unos pocos

### Parte 7

**As arrogant as she was** : Es tan arrogante como ella.

**Biggest revenue**: Mayores ingresos.

**For my stubborn attitude** : Por mi actitud testaruda.

**I realise why you misunderstood** : Me doy cuenta de por qué lo has entendido mal.

**I can see why you thought (that)** : Entiendo por qué lo pensaste.

**That's not actually true.** : En realidad, no es cierto.

**When I said... what I actually meant was…** : Cuando dije.. lo que quería decir en realidad era.

**Actually meant** : En realidad quería decir.

**Isn't keen** : No es entusiasta.

**I didn't explain myself well.** : No me he explicado bien.

**What did you hear me say?** : ¿ Qué es lo que has entendido ?

**To take it the wrong way** : Tomárselo a mal.

**An agenda** : Un orden del día, un programa, una agenda.

**by 5pm.** : Antes de las 17:00 horas.

---

**AOB?** : (Any other business) otras cuestiones

**Commuting costs** : Gastos de desplazamiento.

**Turn to** : Girar a, A su vez a, pasar a, volver a.

---

**Steer clear of the infamous** : Evite el infame.

**Steer clear** : Evitar.

**And further on** : Y más adelante.

**She stresses** : Ella subraya, destaca, hace hincapié en, subraya que.

**Points out why** : Señala por qué.

**At the beginning, the author argues that...** : Al principio el autor defiende que.

**Further on, the author examines why...** : Más adelante, la autora analiza por qué.

**For ills so immeasurable** : Por males tan inconmensurables.

**Time and silence are the only medicine** : El tiempo y silencio son la única medicina.

**Lacked words** : Faltaban palabras, le faltaban palabras, falta de palabras.

**Eloquently express his sympathy.** : Expresar elocuentemente su simpatía.